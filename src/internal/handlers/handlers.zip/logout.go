package handlers

import (
	"encoding/json"
	"github.com/Milad-Abooali/dev-csiran-auth/src/internal/memory"
	"github.com/gorilla/websocket"
)

type LogoutRequest struct {
	Token string `json:"token"`
}

// HandleLogout logs the user out by deleting the session token
func HandleLogout(conn *websocket.Conn, raw json.RawMessage) {
	var req LogoutRequest
	if err := json.Unmarshal(raw, &req); err != nil || req.Token == "" {
		sendError(conn, "invalid_logout_payload")
		return
	}

	memory.DeleteToken(req.Token)

	resp := map[string]interface{}{
		"type": "logout_ok",
		"data": map[string]string{
			"message": "logged out",
		},
	}
	conn.WriteJSON(resp)
}
