package handlers

import (
	"encoding/json"
	"fmt"
	"log"
	"strings"

	"github.com/Milad-Abooali/dev-csiran-auth/src/internal/grpcclient"
	"github.com/gorilla/websocket"
)

type ResetRequest struct {
	Username    string `json:"username"`
	NewPassword string `json:"newPassword"`
}

func HandleReset(conn *websocket.Conn, raw json.RawMessage) {
	var req ResetRequest
	if err := json.Unmarshal(raw, &req); err != nil {
		sendError(conn, "invalid_reset_payload")
		return
	}

	if req.Username == "" || req.NewPassword == "" {
		sendError(conn, "missing_required_fields")
		return
	}

	query := fmt.Sprintf("UPDATE users SET password = MD5('%s') WHERE email = '%s'", req.NewPassword, strings.ToLower(req.Username))
	res, err := grpcclient.SendQuery(query)
	if err != nil || res == nil || res.Error != "" {
		log.Println("[reset] gRPC error:", err, res.Error)
		sendError(conn, "reset_failed")
		return
	}

	data := res.Data.GetFields()
	if affected, ok := data["rows_affected"]; !ok || int(affected.GetNumberValue()) < 1 {
		sendError(conn, "reset_failed")
		return
	}

	resp := map[string]interface{}{
		"type": "reset_ok",
		"data": "Password updated successfully",
	}
	conn.WriteJSON(resp)
}
