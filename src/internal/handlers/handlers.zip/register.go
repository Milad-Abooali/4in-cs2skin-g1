package handlers

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/Milad-Abooali/dev-csiran-auth/src/internal/grpcclient"
	"github.com/gorilla/websocket"
)

type RegisterRequest struct {
	Email       string `json:"email"`
	Password    string `json:"password"`
	FirstName   string `json:"first_name"`
	LastName    string `json:"last_name"`
	DisplayName string `json:"display_name"`
}

// HandleRegister inserts a new user into Core DB
func HandleRegister(conn *websocket.Conn, raw json.RawMessage) {
	var req RegisterRequest
	if err := json.Unmarshal(raw, &req); err != nil {
		sendError(conn, "invalid_register_payload")
		return
	}

	// Sanitize and build query
	query := fmt.Sprintf(
		`INSERT INTO users (email, password, first_name, last_name, display_name) 
				VALUES ('%s', MD5('%s'), '%s', '%s', '%s')`,
		strings.ToLower(req.Email),
		req.Password,
		req.FirstName,
		req.LastName,
		req.DisplayName,
	)

	res, err := grpcclient.SendQuery(query)
	if err != nil || res == nil || res.Status != "ok" {
		sendError(conn, "register_failed", res.Error)
		// Error | register_failed
		SendWSResponse(conn, "register", 0, nil, &WSError{
			Code:    "register_failed",
			Message: errorMessage("register_failed"),
			Detail:  res.Error,
		})
		return
	}
	// Extract inserted_id from nested struct
	data := res.Data.GetFields()
	id := int(data["inserted_id"].GetNumberValue())
	if id < 1 {
		// Error | register_failed
		SendWSResponse(conn, "register", 0, nil, &WSError{
			Code:    "register_failed",
			Message: errorMessage("register_failed"),
			Detail:  "inserted_id is not a valid number",
		})
		return
	}

	// Success - register
	SendWSResponse(conn, "register", 1, map[string]interface{}{
		"user_id": id,
	}, nil)
}
