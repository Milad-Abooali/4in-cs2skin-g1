package handlers

import (
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/Milad-Abooali/dev-csiran-auth/src/internal/grpcclient"
	"github.com/Milad-Abooali/dev-csiran-auth/src/internal/memory"
	"github.com/Milad-Abooali/dev-csiran-auth/src/utils"
	"github.com/gorilla/websocket"
)

type LoginRequest struct {
	Email      string `json:"email"`
	Password   string `json:"password"`
	RememberIn int    `json:"remember_in"` // in minutes
}

// HandleLogin checks credentials and generates session token
func HandleLogin(conn *websocket.Conn, raw json.RawMessage) {
	var req LoginRequest
	if err := json.Unmarshal(raw, &req); err != nil {
		sendError(conn, "invalid_login_payload")
		return
	}

	// Validate required fields
	if req.Email == "" || req.Password == "" || req.RememberIn <= 0 {
		sendError(conn, "missing_required_fields")
		return
	}

	// Query to check user credentials (email + MD5 hashed password)
	query := fmt.Sprintf(
		`SELECT display_name FROM users WHERE email='%s' AND password=MD5('%s') LIMIT 1`,
		strings.ToLower(req.Email),
		req.Password,
	)

	res, err := grpcclient.SendQuery(query)
	if err != nil || res == nil || res.Error != "" || res.Data == nil {
		sendError(conn, "invalid_credentials")
		return
	}

	fields := res.Data.GetFields()
	row0, ok := fields["0"]
	if !ok || row0 == nil || row0.GetStructValue() == nil {
		sendError(conn, "invalid_credentials")
		return
	}

	userFields := row0.GetStructValue().GetFields()
	displayName := ""
	if val, ok := userFields["display_name"]; ok {
		displayName = val.GetStringValue()
	}

	// Generate JWT token
	duration := time.Duration(req.RememberIn) * time.Minute
	token, err := utils.GenerateJWT(req.Email, duration)
	if err != nil {
		sendError(conn, "token_generation_failed")
		return
	}

	// Save JWT in memory for session tracking
	memory.SetToken(token, req.Email, duration)

	resp := map[string]interface{}{
		"type": "login_ok",
		"data": map[string]interface{}{
			"display_name": displayName,
			"token":        token,
		},
	}
	conn.WriteJSON(resp)
}
