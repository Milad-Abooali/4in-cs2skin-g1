package handlers

import (
	"encoding/json"
	"github.com/Milad-Abooali/dev-csiran-auth/src/internal/memory"
	"github.com/Milad-Abooali/dev-csiran-auth/src/utils"

	"github.com/gorilla/websocket"
	"time"
)

type ValidateRequest struct {
	Token string `json:"token"`
}

// HandleValidateLogin verifies token validity and remaining time
func HandleValidateLogin(conn *websocket.Conn, raw json.RawMessage) {
	var req ValidateRequest
	if err := json.Unmarshal(raw, &req); err != nil || req.Token == "" {
		sendError(conn, "invalid_validate_payload")
		return
	}

	// Step 1: validate JWT signature
	email, err := utils.ValidateJWT(req.Token)
	if err != nil {
		sendError(conn, "invalid_token_signature")
		return
	}

	// Step 2: check in-memory session map
	session, ok := memory.GetToken(req.Token)
	if !ok || session.Email != email {
		sendError(conn, "token_expired_or_not_found")
		return
	}

	remaining := session.ExpiresAt.Sub(time.Now())

	resp := map[string]interface{}{
		"type": "validate_ok",
		"data": map[string]interface{}{
			"email":          session.Email,
			"remaining_time": int(remaining.Minutes()),
		},
	}
	conn.WriteJSON(resp)
}
