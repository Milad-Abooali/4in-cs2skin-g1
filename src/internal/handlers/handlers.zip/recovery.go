package handlers

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"time"

	"github.com/Milad-Abooali/dev-csiran-auth/src/internal/memory"
	"github.com/gorilla/websocket"
)

type RecoveryRequest struct {
	Email string `json:"email"`
}

// HandlePassRecovery generates a temporary token for password reset
func HandlePassRecovery(conn *websocket.Conn, raw json.RawMessage) {
	var req RecoveryRequest
	if err := json.Unmarshal(raw, &req); err != nil || req.Email == "" {
		sendError(conn, "invalid_recovery_payload")
		return
	}

	// Generate random token
	tokenBytes := make([]byte, 16)
	_, _ = rand.Read(tokenBytes)
	token := hex.EncodeToString(tokenBytes)

	memory.SetRecoveryToken(req.Email, token, 15*time.Minute)

	// TODO: In production, send this via email
	resp := map[string]interface{}{
		"type": "recovery_ok",
		"data": map[string]string{
			"reset_token": token,
			"message":     "token generated",
		},
	}
	conn.WriteJSON(resp)
}
